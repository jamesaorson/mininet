#!/usr/bin/python
# CS 6250 Fall 2024- SDN Firewall Project with POX
# build hackers-45

from pox.core import core
import pox.openflow.libopenflow_01 as of
import pox.lib.packet as pkt
from pox.lib.revent import *
from pox.lib.addresses import IPAddr, EthAddr

# You may use this space before the firewall_policy_processing function to add any extra function that you
# may need to complete your firewall implementation.  No additional functions "should" be required to complete
# this assignment.

"""Instructions:
1. Create an OpenFlow Flow Modification object
2. Create a POX Packet Matching object that will integrate the elements from a single entry in
   the firewall configuration rule file (which is passed in the policy dictionary) to match the
   different IP and TCP/UDP headers if there is anything to match (i.e., no “-“ should be passed
   to the match object, nor should None be passed to a match object if a “-“ is provided).
3. Create a POX Output Action, if needed, to specify what to do with the traffic.
"""

"""
TODO: Failed testcase from alt:
Passed 45 / 46
failed testcases:
15: h43 -> h8 with T at 231, should be True, current False
"""


class Policy:
    PRIORITY_BLOCK = 0
    PRIORITY_ALLOW = 10001

    # Found in libopenflow_01.py in the POX source code
    OFPP_NORMAL = 65530

    def __init__(self, policy_dict: dict):
        self.rulenum = policy_dict["rulenum"]
        self.action = policy_dict["action"].lower()
        self.mac_src = (
            EthAddr(policy_dict["mac-src"]) if policy_dict["mac-src"] != "-" else None
        )
        self.mac_dst = (
            EthAddr(policy_dict["mac-dst"]) if policy_dict["mac-dst"] != "-" else None
        )
        self.ip_src = policy_dict["ip-src"] if policy_dict["ip-src"] != "-" else None
        self.ip_dst = policy_dict["ip-dst"] if policy_dict["ip-dst"] != "-" else None
        self.ip_protocol = (
            int(policy_dict["ipprotocol"]) if policy_dict["ipprotocol"] != "-" else None
        )
        self.port_src = (
            int(policy_dict["port-src"]) if policy_dict["port-src"] != "-" else None
        )
        self.port_dst = (
            int(policy_dict["port-dst"]) if policy_dict["port-dst"] != "-" else None
        )
        self.comment = policy_dict["comment"]

    def make_rule(self) -> of.ofp_flow_mod:
        rule = of.ofp_flow_mod()
        rule.priority = (
            self.PRIORITY_ALLOW
            if self.action.lower() == "allow"
            else self.PRIORITY_BLOCK
        )
        rule.match = of.ofp_match(
            dl_type=pkt.ethernet.IP_TYPE,
            dl_src=self.mac_src,
            dl_dst=self.mac_dst,
            nw_src=self.ip_src,
            nw_dst=self.ip_dst,
            tp_src=self.port_src,
            tp_dst=self.port_dst,
            nw_proto=self.ip_protocol,
        )
        # If blocking, we do not need to add an action
        if self.action == "block":
            return rule
        rule.actions.append(of.ofp_action_output(port=self.OFPP_NORMAL))
        return rule


def firewall_policy_processing(policies):
    """
    This is where you are to implement your code that will build POX/Openflow Match and Action operations to
    create a dynamic firewall meeting the requirements specified in your configure.pol file.  Do NOT hardcode
    the IP/MAC Addresses/Protocols/Ports that are specified in the project description - this code should use
    the values provided in the configure.pol to implement the firewall.

    The policies passed to this function is a list of dictionary objects that contain the data imported from the
    configure.pol file.  The policy variable in the "for policy in policies" represents a single line from the
    configure.pol file.  Each of the configuration values are then accessed using the policy['field'] command.
    The fields are:  'rulenum','action','mac-src','mac-dst','ip-src','ip-dst','ipprotocol','port-src','port-dst',
    'comment'.

    Your return from this function is a list of flow_mods that represent the different rules in your configure.pol file.

    Implementation Hints:
    The documentation for the POX controller is available at https://noxrepo.github.io/pox-doc/html .  This project
    is using the gar-experimental branch of POX in order to properly support Python 3.  To complete this project, you
    need to use the OpenFlow match and flow_modification routines (https://noxrepo.github.io/pox-doc/html/#openflow-messages
    for flow_mod and https://noxrepo.github.io/pox-doc/html/#match-structure for match.)  Also, do NOT wrap IP Addresses with
    IPAddr() unless you reformat the CIDR notation.  Look at the https://github.com/att/pox/blob/master/pox/lib/addresses.py
    for what POX is expecting as an IP Address.
    """

    rules = []
    for policy in map(Policy, policies):
        # Enter your code here to implement matching and block/allow rules.  See the links
        # in Implementation Hints on how to do this.
        # HINT:  Think about how to use the priority in your flow modification.

        # Please note that you need to redefine this variable below to create a valid POX Flow Modification Object
        rule = policy.make_rule()

        # End Code Here
        print("Added Rule ", policy.rulenum, ": ", policy.comment)
        # print(rule)   #Uncomment this to debug your "rule"
        rules.append(rule)

    return rules
